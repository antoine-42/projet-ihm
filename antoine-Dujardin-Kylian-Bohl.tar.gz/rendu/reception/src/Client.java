class Client {
	String lastName;
	String name;

	Client(String lastName_, String name_){
		this.lastName = lastName_;
		this.name = name_;
	}
}