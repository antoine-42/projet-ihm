class RoomType {
    static final String[] TYPE = {
		"Lit simple",
		"Lit double",
		"Deux lits simples"
	};
}