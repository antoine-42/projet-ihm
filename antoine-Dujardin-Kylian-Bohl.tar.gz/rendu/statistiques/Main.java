import java.awt.* ;

public class Main
{
	public static void main(String[] args)
	{		
		Fenetre menu = new Fenetre() ;
		menu.setVisible(true) ;		
	}
	
}
